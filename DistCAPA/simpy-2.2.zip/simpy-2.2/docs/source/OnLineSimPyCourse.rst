SimPy Course on the Web
=======================

An outstanding tutorial on SimPy by Prof. Norm Matloff (U. of California at
Davis) can be found on the Web:  `A Discrete-Event Simulation Course Based on
the SimPy Language <http://heather.cs.ucdavis.edu/~matloff/simcourse.html>`_.

This course material has been developed by Prof. Matloff in his SimPy courses
at U. of California. It is being evolved further, so keep going back to this
great teaching material!
