===============
Getting Started
===============

.. toctree::
   :maxdepth: 1

   Manuals/INSTALLATION
   Manuals/DISTRIBUTION_CONTENTS
   Manuals/CHANGES_FROM_PREVIOUS_VERSION
   Manuals/COMPATIBILITY
   Manuals/HISTORY
   Manuals/RESOURCES
