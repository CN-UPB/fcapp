#!/usr/bin/env python
# coding=utf-8
# $Revision$ $Date$ kgm
"""Monitor 2.1  This dummy module is only provided for backward compatibility.
It does nothing. class Monitor is now part of Simulation
and SimulationXXX."""
__version__ ='2.1.0 $Revision$ $Date$'
pass   
